package com.example.intelligentai;

public class Bot {
    public final String id;
    public final String name;
    public final String tagline;
    public final String bio;
    public final int accentColor;
    public final String systemPrompt;
    public final String[] starters;
    public final int iconRes;

    public Bot(String id, String name, String tagline, String bio, int accentColor,
               String systemPrompt, String[] starters, int iconRes) {
        this.id = id;
        this.name = name;
        this.tagline = tagline;
        this.bio = bio;
        this.accentColor = accentColor;
        this.systemPrompt = systemPrompt;
        this.starters = starters;
        this.iconRes = iconRes;
    }
}
