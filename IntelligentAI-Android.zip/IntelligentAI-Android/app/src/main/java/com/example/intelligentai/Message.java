package com.example.intelligentai;

public class Message {
    public static final String ROLE_USER = "user";
    public static final String ROLE_ASSISTANT = "assistant";

    public final String role;
    public final String content;

    public Message(String role, String content) {
        this.role = role;
        this.content = content;
    }
}
