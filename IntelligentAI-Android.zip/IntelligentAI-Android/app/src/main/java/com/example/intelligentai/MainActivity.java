package com.example.intelligentai;

import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private List<Bot> bots;
    private Bot activeBot;
    private final Map<String, List<Message>> chatHistories = new HashMap<>();

    private RecyclerView botRecyclerView;
    private RecyclerView messageRecyclerView;
    private TextView headerName, headerBio, typingIndicator, clearChatButton;
    private EditText messageInput;
    private ImageButton sendButton;

    private BotAdapter botAdapter;
    private MessageAdapter messageAdapter;
    private boolean loading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bots = BotRepository.getBots();
        for (Bot b : bots) {
            chatHistories.put(b.id, new ArrayList<>());
        }
        activeBot = bots.get(0);

        botRecyclerView = findViewById(R.id.botRecyclerView);
        messageRecyclerView = findViewById(R.id.messageRecyclerView);
        headerName = findViewById(R.id.headerName);
        headerBio = findViewById(R.id.headerBio);
        typingIndicator = findViewById(R.id.typingIndicator);
        clearChatButton = findViewById(R.id.clearChatButton);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        botRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        botAdapter = new BotAdapter(bots, activeBot.id, this::switchBot);
        botRecyclerView.setAdapter(botAdapter);

        messageRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        clearChatButton.setOnClickListener(v -> {
            chatHistories.get(activeBot.id).clear();
            refreshMessages();
        });

        sendButton.setOnClickListener(v -> attemptSend());

        renderHeader();
        refreshMessages();
    }

    private void switchBot(Bot bot) {
        if (loading) return; // keep it simple: don't switch mid-request
        activeBot = bot;
        renderHeader();
        refreshMessages();
    }

    private void renderHeader() {
        headerName.setText(activeBot.name);
        headerName.setTextColor(activeBot.accentColor);
        headerBio.setText(activeBot.bio);

        GradientDrawable sendBg = new GradientDrawable();
        sendBg.setShape(GradientDrawable.OVAL);
        sendBg.setColor(activeBot.accentColor);
        sendButton.setBackground(sendBg);
        sendButton.setColorFilter(0xFF0A0B0F, PorterDuff.Mode.SRC_IN);

        typingIndicator.setTextColor(activeBot.accentColor);
        typingIndicator.setText(activeBot.name.split(" ")[0] + " is typing…");
    }

    private void refreshMessages() {
        List<Message> history = chatHistories.get(activeBot.id);
        messageAdapter = new MessageAdapter(history, activeBot);
        messageRecyclerView.setAdapter(messageAdapter);
        if (!history.isEmpty()) {
            messageRecyclerView.scrollToPosition(history.size() - 1);
        }
    }

    private void attemptSend() {
        String text = messageInput.getText().toString().trim();
        if (TextUtils.isEmpty(text) || loading) return;

        List<Message> history = chatHistories.get(activeBot.id);
        history.add(new Message(Message.ROLE_USER, text));
        messageInput.setText("");
        messageAdapter.notifyItemInserted(history.size() - 1);
        messageRecyclerView.scrollToPosition(history.size() - 1);

        setLoading(true);

        ApiClient.sendMessage(activeBot, history, new ApiClient.ReplyCallback() {
            @Override
            public void onSuccess(String replyText) {
                runOnUiThread(() -> {
                    history.add(new Message(Message.ROLE_ASSISTANT, replyText));
                    messageAdapter.notifyItemInserted(history.size() - 1);
                    messageRecyclerView.scrollToPosition(history.size() - 1);
                    setLoading(false);
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    setLoading(false);
                });
            }
        });
    }

    private void setLoading(boolean isLoading) {
        this.loading = isLoading;
        typingIndicator.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        sendButton.setEnabled(!isLoading);
    }
}
