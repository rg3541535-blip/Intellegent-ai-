package com.example.intelligentai;

import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_USER = 0;
    private static final int TYPE_BOT = 1;

    private final List<Message> messages;
    private final Bot activeBot;

    public MessageAdapter(List<Message> messages, Bot activeBot) {
        this.messages = messages;
        this.activeBot = activeBot;
    }

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).role.equals(Message.ROLE_USER) ? TYPE_USER : TYPE_BOT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == TYPE_USER ? R.layout.item_message_user : R.layout.item_message_bot;
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return new MessageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message m = messages.get(position);
        MessageViewHolder vh = (MessageViewHolder) holder;
        vh.text.setText(m.content);

        if (m.role.equals(Message.ROLE_ASSISTANT)) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(16f * vh.itemView.getResources().getDisplayMetrics().density);
            bg.setColor(withAlpha(activeBot.accentColor, 32));
            bg.setStroke(1, withAlpha(activeBot.accentColor, 90));
            vh.text.setBackground(bg);
        }
    }

    private int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView text;

        MessageViewHolder(@NonNull View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.messageText);
        }
    }
}
