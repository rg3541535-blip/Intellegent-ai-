package com.example.intelligentai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ApiClient {

    // IMPORTANT: this must point to YOUR OWN backend proxy, not api.anthropic.com directly.
    // A native app cannot safely hold a secret API key -- anyone can decompile the APK and
    // extract it. Stand up a small server (Node/Express, Cloudflare Worker, etc.) that holds
    // the real Anthropic key and forwards requests here. This endpoint is a placeholder.
    private static final String BACKEND_URL = "https://your-backend.example.com/api/chat";

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();

    public interface ReplyCallback {
        void onSuccess(String replyText);
        void onError(String errorMessage);
    }

    public static void sendMessage(Bot bot, List<Message> history, ReplyCallback callback) {
        try {
            JSONObject body = new JSONObject();
            body.put("model", "claude-sonnet-4-6");
            body.put("max_tokens", 1000);
            body.put("system", bot.systemPrompt);

            JSONArray messages = new JSONArray();
            for (Message m : history) {
                JSONObject msg = new JSONObject();
                msg.put("role", m.role);
                msg.put("content", m.content);
                messages.put(msg);
            }
            body.put("messages", messages);

            RequestBody requestBody = RequestBody.create(body.toString(), JSON);
            Request request = new Request.Builder()
                    .url(BACKEND_URL)
                    .post(requestBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onError("Network error: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    try (Response r = response) {
                        String responseBody = r.body() != null ? r.body().string() : "";
                        if (!r.isSuccessful()) {
                            callback.onError("Server error (" + r.code() + ")");
                            return;
                        }
                        JSONObject json = new JSONObject(responseBody);
                        JSONArray content = json.optJSONArray("content");
                        StringBuilder text = new StringBuilder();
                        if (content != null) {
                            for (int i = 0; i < content.length(); i++) {
                                JSONObject block = content.getJSONObject(i);
                                if ("text".equals(block.optString("type"))) {
                                    text.append(block.optString("text"));
                                }
                            }
                        }
                        String finalText = text.length() > 0 ? text.toString() : "(no response, try again)";
                        callback.onSuccess(finalText);
                    } catch (Exception e) {
                        callback.onError("Couldn't parse response: " + e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            callback.onError("Request build error: " + e.getMessage());
        }
    }
}
