package com.example.intelligentai;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BotAdapter extends RecyclerView.Adapter<BotAdapter.ViewHolder> {

    public interface OnBotSelected {
        void onSelected(Bot bot);
    }

    private final List<Bot> bots;
    private final OnBotSelected listener;
    private String selectedId;

    public BotAdapter(List<Bot> bots, String initialSelectedId, OnBotSelected listener) {
        this.bots = bots;
        this.selectedId = initialSelectedId;
        this.listener = listener;
    }

    public void setSelected(String id) {
        this.selectedId = id;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bot, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Bot bot = bots.get(position);
        boolean isActive = bot.id.equals(selectedId);

        holder.name.setText(bot.name);
        holder.tagline.setText(bot.tagline);
        holder.icon.setImageResource(bot.iconRes);
        holder.icon.setColorFilter(bot.accentColor);

        int textColor = isActive ? bot.accentColor : Color.parseColor("#E2E8F0");
        holder.name.setTextColor(textColor);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(14f);
        bg.setColor(isActive ? withAlpha(bot.accentColor, 38) : Color.TRANSPARENT);
        holder.root.setBackground(bg);

        holder.root.setOnClickListener(v -> {
            selectedId = bot.id;
            notifyDataSetChanged();
            listener.onSelected(bot);
        });
    }

    private int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    @Override
    public int getItemCount() {
        return bots.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View root;
        ImageView icon;
        TextView name;
        TextView tagline;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.itemRoot);
            icon = itemView.findViewById(R.id.botIcon);
            name = itemView.findViewById(R.id.botName);
            tagline = itemView.findViewById(R.id.botTagline);
        }
    }
}
